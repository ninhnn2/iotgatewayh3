// SPDX-License-Identifier: GPL-2.0-only
#include "../../../../lib/fonts/font_acorn_8x8.c"
